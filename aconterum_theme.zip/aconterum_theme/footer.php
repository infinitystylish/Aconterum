		<div id="footer">
			
		</div>

	</div>

	<?php wp_footer(); ?>
	<script>
    WebFont.load({
      google: {
        families: ["Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic","Montserrat:400,700","Merriweather:300,400,700,900","Balthazar:regular"]
      }
    });
  </script>
	
	<!-- Don't forget analytics -->
	
</body>

</html>
